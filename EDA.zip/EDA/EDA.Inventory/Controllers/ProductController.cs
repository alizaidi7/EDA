﻿using EDA.Customer.Data;
using EDA.Inventory.RabbitMq;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;

namespace EDA.Inventory.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private ProductDbContext _productDbContext;
        private IRabbitMqUtil _rabbitMqUtil;
        public ProductController(ProductDbContext productDbContext, IRabbitMqUtil rabbitMqUtil)
        {
            _productDbContext = productDbContext;
            _rabbitMqUtil = rabbitMqUtil;
        }

        [HttpPost]
        [Route("/create")]
        public async Task<ActionResult<Product>> Create(Product product)
        {
            _productDbContext.Products.Add(product);
            await _productDbContext.SaveChangesAsync();

            var productJson = JsonSerializer.Serialize(new
            {
                product.Id,
                product.Name,
                product.ProductId,
                product.Quantity
            });
            await _rabbitMqUtil.PublishMessageQueue("EDA.Queue.Product", productJson);
            return CreatedAtAction("GetAll", new { product.Id }, product);
        }

        [HttpGet]
        [Route("/getAll")]
        public async Task<IEnumerable<Product>> GetAll()
        {
            return await _productDbContext.Products.ToListAsync();
        }

        //[HttpPut]
        //[Route("/update")]
        //public async Task<ActionResult<Product>> Update(Product product)
        //{
        //    _productDbContext.Products.Update(product);
        //    await _productDbContext.SaveChangesAsync();
        //    var productJson = JsonSerializer.Serialize(new
        //    {
        //        product.Id,
        //        product.Name,
        //        product.ProductId
        //    });
        //    await _rabbitMqUtil.PublishMessageQueue("EDA.Queue.Product", productJson);
        //    return CreatedAtAction("GetAll", new { product.Id }, product);
        //}
    }
}
