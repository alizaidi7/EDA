﻿using EDA.Customer.Data;
using EDA.Customer.RabbitMq;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;

namespace EDA.Customer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        private CustomerDbContext _customerDbContext;
        private IRabbitMqUtil _rabbitMqUtil;

        public CustomerController(CustomerDbContext customerDbContext,IRabbitMqUtil rabbitMqUtil)
        {
            _customerDbContext = customerDbContext;
            _rabbitMqUtil= rabbitMqUtil;
        }

        [HttpPost]
        [Route("/create")]
        public async Task Create(Data.Customer customer)
        {
            _customerDbContext.Customers.Add(customer);

            var product = await _customerDbContext.Products.FirstOrDefaultAsync(o => o.ProductId == customer.ProductId);
            product.Quantity = product.Quantity - customer.ItemInCart;

            await _customerDbContext.SaveChangesAsync();            

            var customerJson = JsonSerializer.Serialize(new
            {
                customer.Id,
                customer.Name,
                customer.ProductId,
                customer.ItemInCart
            });
            await _rabbitMqUtil.PublishMessageQueue("EDA.Queue.Customer", customerJson);
        }


        [HttpGet]
        [Route("/getAll")]
        public async Task<IEnumerable<Data.Customer>> GetAll()
        {
            return await _customerDbContext.Customers.ToListAsync();
        }

        [HttpGet]
        [Route("/getAllProducts")]
        public async Task<IEnumerable<Product>> GetProducts()
        {
            return await _customerDbContext.Products.ToListAsync();
        }
    }
}
