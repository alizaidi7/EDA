﻿using EDA.Customer.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json.Linq;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System.Runtime.InteropServices.JavaScript;
using System.Text;
using System.Threading;

namespace EDA.Customer.RabbitMq
{
    public class RabbitMqUtil : IRabbitMqUtil
    {
        private IServiceScopeFactory _serviceScopeFactory;

        public RabbitMqUtil(IServiceScopeFactory serviceScopeFactory)
        {
            _serviceScopeFactory = serviceScopeFactory;
        }
        public async Task PublishMessageQueue(string routingKey, string eventData)
        {
            var factory = new ConnectionFactory()
            {
                HostName = "localhost",
                UserName = "guest",
                Password = "India@123456"
            };

            using var connection = factory.CreateConnection();
            using var channel = connection.CreateModel();
            var body = Encoding.UTF8.GetBytes(eventData);
            channel.BasicPublish(exchange: "EDA.exchange", routingKey: routingKey, basicProperties: null, body: body);

            await Task.CompletedTask;
        }

        public async Task ListenMessageQueue(IModel channel, string routingKey, CancellationToken cancellationToken)
        {
            var consumer = new AsyncEventingBasicConsumer(channel);
            consumer.Received += async (model, ea) =>
            {
                var bodyJson = Encoding.UTF8.GetString(ea.Body.ToArray());

                await ParseProductMessage(bodyJson, ea, cancellationToken);
            };
            channel.BasicConsume(routingKey, true, consumer);
            await Task.CompletedTask;
        }

        private async Task ParseProductMessage(string message, BasicDeliverEventArgs ea, CancellationToken cancellationToken)
        {
            using var scope = _serviceScopeFactory.CreateScope();
            var customerDbContext = scope.ServiceProvider.GetRequiredService<CustomerDbContext>();

            var data = JObject.Parse(message);
            var type = ea.RoutingKey;

            if (type == "EDA.Queue.Product")
            {
                var guidValue = Guid.Parse(data["ProductId"].Value<string>());
                var product = await customerDbContext.Products.FirstOrDefaultAsync(o => o.ProductId == guidValue, cancellationToken);

                if (product != null)
                {
                    product.Name = data["Name"].Value<string>();
                    product.Quantity = data["Quantity"].Value<int>();
                }
                else
                {
                    await customerDbContext.Products.AddAsync(new Product
                    {
                        ProductId = guidValue,
                        Name = data["Name"].Value<string>(),
                        Quantity = data["Quantity"].Value<int>(),
                    });
                }
                await customerDbContext.SaveChangesAsync();
            }
        }
    }
}
