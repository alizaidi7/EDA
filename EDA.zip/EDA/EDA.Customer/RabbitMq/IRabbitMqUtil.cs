﻿
using RabbitMQ.Client;

namespace EDA.Customer.RabbitMq
{
    public interface IRabbitMqUtil
    {
        Task PublishMessageQueue(string routingKey, string eventData);
        Task ListenMessageQueue(IModel channel, string routingKey, CancellationToken cancellationToken);
    }
}