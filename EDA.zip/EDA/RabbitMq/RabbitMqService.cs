﻿using Microsoft.Extensions.Hosting;
using RabbitMQ.Client;

namespace RabbitMqUtility
{
    public class RabbitMqService : BackgroundService
    {
        private readonly IRabbitMqUtil _rabbitMqUtil;
        private IConnection _connection;
        private IModel _channel;

        public RabbitMqService(IRabbitMqUtil rabbitMqUtil)
        {
            _rabbitMqUtil = rabbitMqUtil;
        }
        public override Task StartAsync(CancellationToken cancellationToken)
        {
            var factory = new ConnectionFactory()
            {
                HostName = "localhost",
                UserName = "guest",
                Password = "India@123456",
                DispatchConsumersAsync = true,
            };

            _connection = factory.CreateConnection();
            _channel = _connection.CreateModel();
            return base.StartAsync(cancellationToken);
        }
        protected override async Task ExecuteAsync(CancellationToken cancellationToken)
        {
            await _rabbitMqUtil.ListenMessageQueue(_channel, "EDA.Queue.Customer", cancellationToken);
        }

        public override Task StopAsync(CancellationToken cancellationToken)
        {
            _channel.Close();
            return base.StopAsync(cancellationToken);
        }
    }
}
