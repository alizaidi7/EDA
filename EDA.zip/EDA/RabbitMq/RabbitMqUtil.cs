﻿using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System.Text;

namespace RabbitMqUtility
{
    public class RabbitMqUtil : IRabbitMqUtil
    {
        public RabbitMqUtil()
        {
        }
        public async Task PublishMessageQueue(string routingKey, string eventData)
        {
            var factory = new ConnectionFactory()
            {
                HostName = "localhost",
                UserName = "guest",
                Password = "India@123456"
            };

            using var connection = factory.CreateConnection();
            using var channel = connection.CreateModel();
            var body = Encoding.UTF8.GetBytes(eventData);
            channel.BasicPublish(exchange: "EDA.exchange", routingKey: routingKey, basicProperties: null, body: body);

            await Task.CompletedTask;
        }

        public async Task ListenMessageQueue(IModel channel, string routingKey, CancellationToken cancellationToken)
        {
            var consumer = new AsyncEventingBasicConsumer(channel);
            consumer.Received += async (model, ea) =>
            {
                var bodyJson = Encoding.UTF8.GetString(ea.Body.ToArray());

                await ParseCustomerMessage(bodyJson, ea, cancellationToken);
            };
            channel.BasicConsume(routingKey, true, consumer);
            await Task.CompletedTask;
        }

        private async Task ParseCustomerMessage(string message, BasicDeliverEventArgs ea, CancellationToken cancellationToken)
        {
            //using var scope = _serviceScopeFactory.CreateScope();
            //var customerDbContext = scope.ServiceProvider.GetRequiredService<ProductDbContext>();

            //var data = JObject.Parse(message);
            //var type = ea.RoutingKey;

            //if (type == "EDA.Queue.Customer")
            //{
            //    var guidValue = Guid.Parse(data["ProductId"].Value<string>());
            //    var product = await customerDbContext.Products.FirstOrDefaultAsync(o => o.ProductId == guidValue, cancellationToken);

            //    var itemInCart = data["ItemInCart"].Value<int>();
            //    var inHandItems = product.Quantity;
            //    if (inHandItems >= itemInCart)
            //    {
            //        product.Quantity = inHandItems - itemInCart;
            //    }
            //    await customerDbContext.SaveChangesAsync();
            //}
            await Task.CompletedTask;
        }

    }
}
